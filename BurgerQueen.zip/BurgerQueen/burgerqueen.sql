-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : dim. 05 fév. 2023 à 15:28
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `burgerqueen`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `price` float NOT NULL,
  `IMG_burgers` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id`, `title`, `price`, `IMG_burgers`) VALUES
(1, 'Whooper', 5.8, './public/images/whopper.webp'),
(2, 'Steackhouse', 6.3, './public/images/steakhouse.webp'),
(3, 'Big Queen', 5.1, './public/images/big_queen.webp'),
(4, 'Double Steackhouse', 8, './public/images/double_steakhouse.webp'),
(5, 'Double Whopper Cheese', 7.7, './public/images/double_whopper_cheese.webp'),
(6, 'Kentucky Steakhouse', 6.9, './public/images/chicken_kentucky_steakhouse.webp'),
(7, 'Veggie Whopper', 5.8, './public/images/veggie_whopper.webp'),
(8, 'Veggie Steakhouse', 6.3, './public/images/veggie_steakhouse.webp'),
(9, 'Big Fish', 5.1, './public/images/big_fish.webp');

-- --------------------------------------------------------

--
-- Structure de la table `boissons`
--

CREATE TABLE `boissons` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `price` float NOT NULL,
  `taille` text NOT NULL,
  `IMG_boissons` text NOT NULL,
  `type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `boissons`
--

INSERT INTO `boissons` (`id`, `title`, `price`, `taille`, `IMG_boissons`, `type`) VALUES
(201, 'Coca-Cola 33cl', 2, 'Normal', './public/images/coca_cola_33.webp', 'Coca-Cola'),
(202, 'Coca-Cola 50cl', 3.5, 'XL', './public/images/coca_cola_50.webp', 'Coca-Cola'),
(203, 'Ice tea 33cl', 2, 'Normal', './public/images/ice_tea_33.webp', 'Ice tea'),
(204, 'Ice tea 50cl', 3.5, 'XL', './public/images/ice_tea_50.webp', 'Ice tea'),
(205, 'Sprite 33cl', 2, 'Normal', './public/images/sprite_33.webp', 'Sprite'),
(206, 'Sprite 50cl', 3.5, 'XL', './public/images/sprite_50.webp', 'Sprite');

-- --------------------------------------------------------

--
-- Structure de la table `frites`
--

CREATE TABLE `frites` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `price` float NOT NULL,
  `IMG_snacks` text NOT NULL,
  `InMenu` int(11) NOT NULL,
  `taille` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `frites`
--

INSERT INTO `frites` (`id`, `title`, `price`, `IMG_snacks`, `InMenu`, `taille`) VALUES
(101, 'Petites frites', 2.1, './public/images/petites_frites.webp', 0, ''),
(102, 'Moyennes frites', 2.5, './public/images/moyennes_frites.webp', 1, 'Normal'),
(103, 'Grandes frites', 2.9, './public/images/grandes_frites.webp', 1, 'XL'),
(104, 'Onion rings', 2.5, './public/images/onion_rings.webp', 0, ''),
(105, 'Queen Wings', 5.4, './public/images/queen_wings.webp', 0, ''),
(106, 'Queen Nuggets', 4.9, './public/images/queen_nuggets.webp', 1, 'Normal');

-- --------------------------------------------------------

--
-- Structure de la table `logos`
--

CREATE TABLE `logos` (
  `title` text NOT NULL,
  `IMG_logos` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `logos`
--

INSERT INTO `logos` (`title`, `IMG_logos`) VALUES
('Coca-Cola', './public/images/Coca_Cola_logo.png'),
('Ice tea', './public/images/ice_tea_logo.jpg'),
('Sprite', './public/images/Sprite_logo.png');

-- --------------------------------------------------------

--
-- Structure de la table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `price` int(11) NOT NULL,
  `taille` text NOT NULL,
  `IMG_menus` text NOT NULL,
  `BurgerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `menus`
--

INSERT INTO `menus` (`id`, `title`, `price`, `taille`, `IMG_menus`, `BurgerID`) VALUES
(301, 'Menu SteackHouse', 10, 'Normal', './public/images/menu_steakhouse.webp', 2),
(302, 'Menu Steackhouse XL', 12, 'XL', '.\\public\\images\\menu_double_steakhouse.webp', 4);

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `cart` text NOT NULL,
  `createdAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `cart`, `createdAt`) VALUES
(2, 2023, '[{\"articleId\":\"2\",\"quantity\":\"1\",\"name\":\"Double Whooper Cheese\",\"price\":\"10.3\",\"totalPrice\":10.3},{\"articleId\":\"5\",\"quantity\":\"2\",\"name\":\"Chicken Steakhouse\",\"price\":\"7.4\",\"totalPrice\":14.8},{\"articleId\":\"102\",\"quantity\":\"2\",\"name\":\"Moyennes frites\",\"price\":\"2.5\",\"totalPrice\":5},{\"articleId\":\"104\",\"quantity\":\"1\",\"name\":\"Onion rings\",\"price\":\"2.5\",\"totalPrice\":2.5}]', '2023-01-08 15:11:18'),
(3, 2023, '[{\"articleId\":\"1\",\"quantity\":\"2\",\"name\":\"Whooper\",\"price\":\"8.6\",\"totalPrice\":17.2},{\"articleId\":\"6\",\"quantity\":\"1\",\"name\":\"Big Queen\",\"price\":\"5.7\",\"totalPrice\":5.7},{\"articleId\":\"103\",\"quantity\":\"1\",\"name\":\"Grandes frites\",\"price\":\"2.9\",\"totalPrice\":2.9},{\"articleId\":\"105\",\"quantity\":\"1\",\"name\":\"Queen Wings\",\"price\":\"5.4\",\"totalPrice\":5.4},{\"articleId\":\"101\",\"quantity\":\"2\",\"name\":\"Petites frites\",\"price\":\"2.1\",\"totalPrice\":4.2}]', '2023-01-08 15:23:18'),
(4, 2023, '[{\"articleId\":\"2\",\"quantity\":\"1\",\"name\":\"Double Whooper Cheese\",\"price\":\"10.3\",\"totalPrice\":10.3},{\"articleId\":\"103\",\"quantity\":\"1\",\"name\":\"Grandes frites\",\"price\":\"2.9\",\"totalPrice\":2.9},{\"articleId\":\"203\",\"quantity\":\"2\",\"name\":\"Lipton Ice Tea pêche (50cl)\",\"price\":\"3.2\",\"totalPrice\":6.4}]', '2023-01-08 17:45:21'),
(5, 2023, '[{\"articleId\":\"1\",\"quantity\":\"1\",\"name\":\"Whooper\",\"price\":\"8.6\",\"totalPrice\":8.6},{\"articleId\":\"3\",\"quantity\":\"1\",\"name\":\"Steakhouse\",\"price\":\"7.9\",\"totalPrice\":7.9},{\"articleId\":\"101\",\"quantity\":\"1\",\"name\":\"Petites frites\",\"price\":\"2.1\",\"totalPrice\":2.1},{\"articleId\":\"204\",\"quantity\":\"2\",\"name\":\"Sprite (50cl)\",\"price\":\"3.2\",\"totalPrice\":6.4}]', '2023-01-09 19:52:56'),
(6, 2023, '[{\"articleId\":\"1\",\"quantity\":\"2\",\"name\":\"Whooper\",\"price\":\"8.6\",\"totalPrice\":17.2},{\"articleId\":\"104\",\"quantity\":\"1\",\"name\":\"Onion rings\",\"price\":\"2.5\",\"totalPrice\":2.5},{\"articleId\":\"105\",\"quantity\":\"1\",\"name\":\"Queen Wings\",\"price\":\"5.4\",\"totalPrice\":5.4},{\"articleId\":\"202\",\"quantity\":\"1\",\"name\":\"Coca-Cola sans sucres (50cl)\",\"price\":\"3.2\",\"totalPrice\":3.2},{\"articleId\":\"205\",\"quantity\":\"1\",\"name\":\"Fanta (50cl)\",\"price\":\"3.2\",\"totalPrice\":3.2}]', '2023-01-09 19:54:40'),
(7, 2023, '[{\"articleId\":\"2\",\"quantity\":\"1\",\"name\":\"Double Whooper Cheese\",\"price\":\"10.3\",\"totalPrice\":10.3},{\"articleId\":\"103\",\"quantity\":\"1\",\"name\":\"Grandes frites\",\"price\":\"2.9\",\"totalPrice\":2.9},{\"articleId\":\"106\",\"quantity\":\"1\",\"name\":\"Queen Nuggets\",\"price\":\"4.9\",\"totalPrice\":4.9},{\"articleId\":\"104\",\"quantity\":\"1\",\"name\":\"Onion rings\",\"price\":\"2.5\",\"totalPrice\":2.5}]', '2023-01-09 19:57:53'),
(8, 2023, '[{\"articleId\":\"2\",\"quantity\":\"1\",\"name\":\"Double Whooper Cheese\",\"price\":\"10.3\",\"totalPrice\":10.3}]', '2023-01-09 22:40:41'),
(9, 2023, '[{\"articleId\":\"2\",\"quantity\":\"1\",\"name\":\"Double Whooper Cheese\",\"price\":\"10.3\",\"totalPrice\":10.3}]', '2023-01-09 22:41:19'),
(10, 2023, '[{\"articleId\":\"1\",\"quantity\":\"2\",\"name\":\"Whooper\",\"price\":\"8.6\",\"totalPrice\":17.2}]', '2023-01-18 19:24:09'),
(11, 2023, '[{\"articleId\":\"1\",\"quantity\":\"1\",\"name\":\"Whooper\",\"price\":\"8.6\",\"totalPrice\":8.6}]', '2023-01-19 15:15:04'),
(12, 2023, '[{\"articleId\":\"201\",\"quantity\":\"1\",\"name\":\"Coca-Cola\",\"price\":\"2\",\"totalPrice\":2},{\"articleId\":\"203\",\"quantity\":\"1\",\"name\":\"Coca-Cola 33cl\",\"price\":\"2\",\"totalPrice\":2},{\"articleId\":\"204\",\"quantity\":\"1\",\"name\":\"Coca-Cola 50cl\",\"price\":\"3.5\",\"totalPrice\":3.5},{\"articleId\":\"1\",\"quantity\":\"1\",\"name\":\"Whooper\",\"price\":\"8.7\",\"totalPrice\":8.7}]', '2023-01-20 23:10:55'),
(13, 2023, '[{\"articleId\":\"204\",\"quantity\":\"1\",\"name\":\"Ice tea 50cl\",\"price\":\"3.5\",\"totalPrice\":3.5}]', '2023-01-21 00:01:05'),
(14, 2023, '[{\"articleId\":\"203\",\"quantity\":\"1\",\"name\":\"Ice tea 33cl\",\"price\":\"2\",\"totalPrice\":2},{\"articleId\":\"102\",\"quantity\":\"1\",\"name\":\"Moyennes frites\",\"price\":\"2.5\",\"totalPrice\":2.5},{\"articleId\":\"2\",\"quantity\":\"1\",\"name\":\"Steackhouse\",\"price\":\"9.5\",\"totalPrice\":9.5}]', '2023-01-21 16:26:58'),
(15, 2023, '[{\"articleId\":\"101\",\"quantity\":\"3\",\"name\":\"Petites frites\",\"price\":\"2.1\",\"totalPrice\":6.300000000000001},{\"articleId\":\"1\",\"quantity\":\"1\",\"name\":\"Whooper\",\"price\":\"8.7\",\"totalPrice\":8.7}]', '2023-02-04 16:52:16'),
(16, 2023, '[{\"articleId\":\"101\",\"quantity\":4,\"name\":\"Petites frites\",\"price\":\"2.1\",\"totalPrice\":8.4},{\"articleId\":\"301\",\"quantity\":\"1\",\"name\":\"Menu SteackHouse(Coca-Cola 33cl, Queen Nuggets)\",\"price\":\"10\",\"totalPrice\":10}]', '2023-02-04 16:58:47'),
(17, 2023, '[{\"articleId\":\"301\",\"quantity\":\"1\",\"name\":\"Menu SteackHouse(Ice tea 33cl, Moyennes frites)\",\"price\":\"10\",\"totalPrice\":10},{\"articleId\":\"1\",\"quantity\":\"2\",\"name\":\"Whooper\",\"price\":\"8.7\",\"totalPrice\":17.4},{\"articleId\":\"202\",\"quantity\":\"1\",\"name\":\"Coca-Cola 50cl\",\"price\":\"3.5\",\"totalPrice\":3.5}]', '2023-02-05 11:11:07');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `boissons`
--
ALTER TABLE `boissons`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `frites`
--
ALTER TABLE `frites`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `BurgerID` (`BurgerID`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `menus_ibfk_1` FOREIGN KEY (`BurgerID`) REFERENCES `articles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
