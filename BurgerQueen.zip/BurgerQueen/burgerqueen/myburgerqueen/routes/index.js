var express = require('express');
var router = express.Router();

router.use('/public', express.static('public'));

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Accueil' });
});



/* GET menu page. */
router.get('/menus', function(req, res) {

  var con = req.con;
  con.query("SELECT * FROM menus", function (err, results, fields) {
    if (err) throw err;
    res.render('menus', { title: 'Menus' , menus: results });
  });
});


/* GET le détail du menu  */
router.get('/detail_menu', function(req, res) {
  var con = req.con;
  var menutitle = req.query.menu;
  var taillemenu = req.query.taille;
  let data=[];
  con.query("SELECT * FROM articles WHERE id=(SELECT BurgerID FROM menus WHERE title=?)",[menutitle], function (err, results, fields) {
    if (err) throw err;
    data.push(results);
    con.query("SELECT * FROM boissons WHERE taille=? ",[taillemenu], function (err, results, fields) {
      if (err) throw err;
      data.push(results);
      con.query("SELECT * FROM frites WHERE taille=? and InMenu=1",[taillemenu], function (err, results, fields) {
        if (err) throw err;
        data.push(results);
        con.query("SELECT * FROM menus WHERE title=?",[menutitle], function (err, results, fields) {
          if (err) throw err;
          data.push(results);


          res.render('detail_menu', { title: menutitle , menudetail : data });
        });
      });
    });
  });
});



/* GET burgers page. */
router.get('/burgers', function(req, res) {
  var con = req.con;
  con.query("SELECT * FROM articles", function (err, results, fields) {
    if (err) throw err;
    res.render('burgers', { title: 'Burgers' , articles: results });
  });
});

/* GET snacks page. */
router.get('/snacks', function(req, res) {
  var con = req.con;
  con.query("SELECT * FROM frites", function (err, results, fields) {
    if (err) throw err;
    res.render('snacks', { title: 'Snacks' , articles: results });
  });
});

/* GET boissons page. */
router.get('/boissons', function(req, res) {
  var con = req.con;
  con.query("SELECT * FROM logos", function (err, results, fields) {
    if (err) throw err;
    res.render('boissons', { title: 'Boissons' , logo_boissons: results });
  });
});


/* GET choix boissons page. */

router.get('/choix_taille_boissons', function(req, res) {
  var con = req.con;
  var boisson = req.query.boisson
  con.query("SELECT * FROM boissons WHERE title LIKE ?",[boisson+"%"], function (err, results, fields) {
    if (err) throw err;
    res.render('choix_taille_boissons', { title: boisson, boissons : results});
  });
});


router.get('/test', function(req, res, next) {
  res.render('test', { title: 'Test' });
});


// Ajout des articles au panier
router.post('/add-to-cart', (req, res) => {
  // Récupération des données envoyées via le formulaire
  
  const articleId = req.body.articleId;
  const quantity = req.body.quantity;
  const name = req.body.articleName;
  const price = req.body.articlePrice;

  // Ajout de l'article au panier de l'utilisateur
  addToCart(articleId, quantity, name, price,  req, res);
  res.redirect('back');
});

//Ajout d'un menu au panier
router.post('/menu-add-to-cart', (req, res) => {
  // Récupération des données envoyées via le formulaire
  
  const articleId = req.body.articleId;
  const quantity = req.body.quantity;
  var name = req.body.articleName;
  const price = req.body.articlePrice;
  const boissonname=req.body.boissons;
  const accompagnementname=req.body.accompagnements;

  //On récupère la boisson et l'accompagnement choisi et on l'ajoute au nom du menu
  name=name+"("+boissonname+", "+accompagnementname+")";
  // Ajout de l'article au panier de l'utilisateur
  addToCart(articleId, quantity, name, price,  req, res);
  res.redirect('back');
});

// /* GET cart page. */
router.get('/cart', (req, res) => {
  const cart = getCart(req);
  var prixtot_Panier =0;
  cart.forEach(articles =>prixtot_Panier+=articles.totalPrice);
  res.render('cart', { title: 'Panier' , cart: cart , Paniertot : prixtot_Panier});
});

router.post('/remove-from-cart', (req, res) => {
  // Récupération de l'ID de l'article à supprimer
  const namearticle = req.body.name;

  // Récupération du panier de l'utilisateur
  const cart = getCart(req);

  // Recherche de l'article dans le panier
  const articleIndex = cart.findIndex((item) => item.name === namearticle);

  // Si l'article est dans le panier, on le supprime
  if (articleIndex !== -1) {
    if(cart[articleIndex].quantity>1){
      cart[articleIndex].quantity=cart[articleIndex].quantity-1;
      cart[articleIndex].totalPrice=cart[articleIndex].quantity*cart[articleIndex].price;
    }
    else{
      cart.splice(articleIndex, 1);
    }
    
  }

  // Enregistrement du panier mis à jour de l'utilisateur
  saveCart(cart, res);

  // Redirection vers la page du panier
  res.redirect('/cart');
});

// Validation du panier sur la deuxième page
router.post('/validate-cart', (req, res) => {
  // Validation du panier et enregistrement de la commande
  checkout(req, res);
});

/* GET orders page. */
router.get('/orders', (req, res) => {
  // Récupération de l'historique des commandes de l'utilisateur
  var userId = 2023;
  var con = req.con;
  con.query('SELECT * FROM orders WHERE userId = ?', [userId], (error, results) => {
    if (error) {
      // Si une erreur survient, on affiche un message d'erreur
      res.render('orders', { error: 'Une erreur est survenue lors de la récupération de votre historique de commandes' });
      return;
    }
    let data = Object.values(JSON.parse(JSON.stringify(results)));
    console.log(results);
    const newCarts = [];
    const dates = [];
    for (let i = 0; i < data.length; i++) {
      const cartJson = data[i].cart;
      const dateString = data[i].createdAt;
      const date = new Date(dateString);
      newCarts[i] = JSON.parse(cartJson);
      const newDate = date.toLocaleString();
      dates[i] = newDate;
    }
    // Si tout s'est bien passé, on envoie les commandes à la vue
    res.render('orders', { title: 'Historique' , dates: dates , carts: newCarts});
  });
});


//*********************** Functions ********************************* */

function addToCart(articleId, quantity, name, price, req, res) {
  // Récupération du panier actuel de l'utilisateur
  let cart = getCart(req);
  // Recherche de l'article dans le panier
  const articleIndex = cart.findIndex((item) => item.name === name);
  // Mise à jour du panier avec le nouvel article
  let updated = false;
  if (articleIndex !== -1) {
      cart[articleIndex].quantity = parseInt(cart[articleIndex].quantity) + parseInt(quantity);
      cart[articleIndex].totalPrice = parseFloat(cart[articleIndex].totalPrice) + parseFloat(price * quantity);
      updated = true;
  }

  if (!updated) {
    cart.push({ articleId: articleId, quantity: quantity, name: name, price, totalPrice: price * quantity});
  }

  // Enregistrement du panier mis à jour de l'utilisateur
  saveCart(cart, res);
}

function getCart(req) {
  // Récupération du panier stocké dans un cookie
  const cartCookie = req.cookies.cart;

  // Si le cookie n'existe pas, on retourne un panier vide
  if (!cartCookie) {
    return [];
  }

  // Décodage du panier depuis le cookie
  return JSON.parse(cartCookie);
}

function saveCart(cart, res) {
  // Enregistrement du panier dans un cookie
  res.cookie('cart', JSON.stringify(cart), { expires: new Date(Date.now() + 3600000) });
}

function checkout(req, res) {
  // Récupération du panier de l'utilisateur
  const cart = getCart(req);

  // Si le panier est vide, on affiche un message d'erreur
  if (cart.length === 0) {
    res.render('cart', { error: 'Vous ne pouvez pas valider votre panier car celui-ci est vide' });
    return;
  }

  // Enregistrement de la commande dans la base de données
  var userId = 2023;
  var con = req.con;
  con.query('INSERT INTO orders (userId, cart) VALUES (?, ?)', [userId, JSON.stringify(cart)], (error) => {
    if (error) {
      // Si une erreur survient, on affiche un message d'erreur
      res.render('cart', { error: 'Une erreur est survenue lors de la validation de votre panier' });
      return;
    }

    // Si tout s'est bien passé, on vide le panier et on affiche la page de confirmation
    res.clearCookie('cart');
    res.render('order', { cart: cart });
  });
}


module.exports = router;
